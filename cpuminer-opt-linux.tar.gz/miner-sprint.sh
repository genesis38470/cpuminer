#!/bin/sh
#
# Choose nearest stratum:
#       stratum-eu.rplant.xyz   /France/
#       stratum-asia.rplant.xyz /Singapore/
#       stratum-na.rplant.xyz   /Canada/
#
FOLDER=$( cd -- "$( dirname -- "${BASH_SOURCE[0]}" )" &> /dev/null && pwd )
while [ 1 ]; do
"$FOLDER"/cpuminer-avx2 -a yespower -o stratum+tcps://stratum-eu.rplant.xyz:17052 -u SkBCm4qiTa7d6UFPn85RTFZHiFNaXXM1J3
sleep 5
done
